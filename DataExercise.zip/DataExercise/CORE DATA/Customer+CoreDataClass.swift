import Foundation
import CoreData

@objc(Customer)
public class Customer: NSManagedObject {

}
