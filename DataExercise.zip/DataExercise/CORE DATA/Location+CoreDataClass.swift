import Foundation
import CoreData

@objc(Location)
public class Location: NSManagedObject {

}
