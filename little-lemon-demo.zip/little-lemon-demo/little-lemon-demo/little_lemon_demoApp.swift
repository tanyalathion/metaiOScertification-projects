//
//  little_lemon_demoApp.swift
//  little-lemon-demo
//
//  Created by Tanya Lathion on 19.06.2024.
//

import SwiftUI

@main
struct little_lemon_demoApp: App {
    var body: some Scene {
        WindowGroup {
            MenuItemsView()
        }
    }
}
